import React, {Component} from 'react';
import {
  Text,
  View,
  Image,
  Dimensions,
  FlatList,
  TouchableOpacity,
  ScrollView,
  StatusBar
} from 'react-native';
const _window = Dimensions.get('window');

class perfilUser extends Component {
  constructor(props) {
    super(props);
    this.state = {
      flatListOn: 'false',
      basicInformation: [
        {
          id: 1,
          name: 'Aldo Hernandez Cruz',
          mail: 'aldodragon12@hotmail.com',
          phone: '7831347315',
        },
        {
          id: 2,
          name: 'Rei Ayanami',
          mail: 'rayeva@hotmail.com',
          phone: '7831331234',
        },
        {
          id: 3,
          name: 'Francisco Gonzales Suares',
          mail: 'fran@gmail.com',
          phone: '7831236349',
        },
        {
          id: 4,
          name: 'Alice Hernandez Jimenes',
          mail: 'alicher@gmail.com',
          phone: '4573460872',
        },
      ],
      hobbies: [],
      hobbiesUserAldo: [
        {hobbie: 'Salir a andar en bici'},
        {hobbie: 'Dormir mucho'},
        {hobbie: 'Leer libros de terror'},
        {hobbie: 'Estudiar'},
      ],
      hobbiesUserRei: [
        {hobbie: 'Practicar alpinismo'},
        {hobbie: 'Cocinar'},
        {hobbie: 'Entrenar'},
        {hobbie: 'Trabajar'},
      ],
      hobbiesUserFrancisco: [
        {hobbie: 'Salir a fiesta'},
        {hobbie: 'Tocar la guitarra'},
        {hobbie: 'Coleccionar monedas'},
        {hobbie: 'Viajar'},
      ],
      hobbiesUserAlice: [
        {hobbie: 'Pescar'},
        {hobbie: 'Acampar'},
        {hobbie: 'Coleccionar estampas de deporte'},
        {hobbie: 'Estudiar'},
      ],
      books: [],
      booksAldo: [
        {book: 'La comunidad del anillo'},
        {book: 'Las dos torres'},
        {book: 'El retorno del rey'},
        {book: 'No me ire sin decirte adios'},
      ],
      booksRei: [
        {book: 'El viento por la cerradura'},
        {book: 'Al final mueren los dos'},
        {book: 'Blaze'},
        {book: 'El mensajero de los corazones rotos'},
      ],
      booksFrancisco: [
        {book: 'Caos'},
        {book: 'Este no es un libro'},
        {book: 'Destroza este diario'},
        {book: 'Predestinados'},
      ],
      booksAlice: [
        {book: 'Cumbres Borrascosas'},
        {book: 'Ciudades de papel'},
        {book: 'El aprendiz del vampiro'},
        {book: 'Amor a cuatro estaciones'},
      ],
      userData: '1',
    };
  }

  UNSAFE_componentWillMount(){
    alert('Bienvenido Al App de Aldo')
  }

  /**
   *Sets the image displayed at the top
   *
   * @return {*} 
   * @memberof perfilUser
   */
  parteSuperior() {
    return (
      <View>
        <Image
          style={{width: _window.width, height: _window.width / 4}}
          source={require('../imagenes/topImage.png')}
        />
      </View>
    );
  }

  /**
   * It is responsible for loading the user's main data
   *
   * @return {*}
   * @memberof perfilUser
   */
  userList() {
    return (
      <View tyle={{flexDirection: 'column'}}>
        <ScrollView horizontal={true} scrollEnabled={false}>
          <FlatList
            data={this.state.basicInformation}
            renderItem={({item}) => this.informationUser(item)}
            keyExtractor={item => item.name}
            contentContainerStyle={{paddingVertical: 2}}
            scrollEnabled={false}
          />
        </ScrollView>
      </View>
    );
  }

  /**
   * It is responsible for indicating the design where the data will be displayed.
   *
   * @param {*} item
   * @return {*}
   * @memberof perfilUser
   */
  informationUser(item) {
    return item.id == this.state.userData ? (
      <View style={{flexDirection: 'column'}}>
        <Text style={{fontSize: 18, fontWeight: 'bold', color: '#333'}}>
          Nombre completo:
        </Text>
        <Text
          style={{
            marginBottom: 15,
            backgroundColor: '#CFA380',
            fontWeight: 'bold',
            alignSelf: 'flex-start',
            paddingHorizontal: 20,
            fontSize: 14,
          }}>
          {item.name}
        </Text>
        <Text style={{fontSize: 18, fontWeight: 'bold', color: '#333'}}>
          Correo Electronico:
        </Text>
        <Text
          style={{
            fontSize: 14,
            marginBottom: 15,
            backgroundColor: '#CFA380',
            fontWeight: 'bold',
            alignSelf: 'flex-start',
            paddingHorizontal: 20,
          }}>
          {item.mail}
        </Text>
        <Text style={{fontSize: 18, fontWeight: 'bold', color: '#333'}}>
          Numero de Telefono:
        </Text>
        <Text
          style={{
            fontSize: 14,
            marginBottom: 15,
            backgroundColor: '#CFA380',
            fontWeight: 'bold',
            alignSelf: 'flex-start',
            paddingHorizontal: 20,
          }}>
          {item.phone}
        </Text>
      </View>
    ) : null;
  }

  /**
   * Takes care of the user's hobbies
   *
   * @return {*}
   * @memberof perfilUser
   */
  hobbiesList() {
    return (
      <View tyle={{flexDirection: 'column'}}>
        <ScrollView horizontal={true} scrollEnabled={false}>
          <FlatList
            data={
              this.state.hobbies == ''
                ? this.state.hobbiesUserAldo
                : this.state.hobbies
            }
            renderItem={({item}) => this.hobbiesUser(item)}
            keyExtractor={item => item.name}
            contentContainerStyle={{paddingVertical: 2}}
            scrollEnabled={false}
          />
        </ScrollView>
      </View>
    );
  }

  /**
   * Responsible for the design of how the hobby will be displayed
   *
   * @param {*} item
   * @return {*}
   * @memberof perfilUser
   */
  hobbiesUser(item) {
    return (
      <View style={{flexDirection: 'column'}}>
        <Text
          style={{
            marginBottom: 15,
            backgroundColor: '#197CBD',
            fontWeight: 'bold',
            alignSelf: 'flex-start',
            paddingHorizontal: 20,
          }}>
          {item.hobbie}
        </Text>
      </View>
    );
  }

  /**
   * Is responsible for loading the user's favorite books
   *
   * @return {*}
   * @memberof perfilUser
   */
  favoriteBooks() {
    return (
      <View tyle={{flexDirection: 'column'}}>
        <ScrollView horizontal={true} scrollEnabled={false}>
          <FlatList
            data={
              this.state.books == '' ? this.state.booksAldo : this.state.books
            }
            renderItem={({item}) => this.booksUser(item)}
            keyExtractor={item => item.name}
            contentContainerStyle={{paddingVertical: 2}}
            scrollEnabled={false}
          />
        </ScrollView>
      </View>
    );
  }

  /**
   * Is responsible for the design of how the list of the user's books will be displayed
   *
   * @param {*} item
   * @return {*}
   * @memberof perfilUser
   */
  booksUser(item) {
    return (
      <View style={{flexDirection: 'column'}}>
        <Text
          style={{
            marginBottom: 15,
            backgroundColor: '#44901B',
            fontWeight: 'bold',
            alignSelf: 'flex-start',
            paddingHorizontal: 20,
          }}>
          {item.book}
        </Text>
      </View>
    );
  }
  render() {
    return (
      <View style={{backgroundColor: '#58A8B2', flex: 1}}>
      <StatusBar
        backgroundColor="#4CAF50"
        barStyle="light-content"
      />
        <ScrollView>
          {this.parteSuperior()}
          <View>
            <View
              style={{
                paddingHorizontal: 15,
                alignItems: 'center',
              }}>
              <Text style={{fontSize: 16, fontWeight: 'bold', color: '#333'}}>
                De que persona quieres saber su informacion:
              </Text>
            </View>
            <View
              style={{
                paddingHorizontal: 15,
                flexDirection: 'row',
                justifyContent: 'space-between',
              }}>
              <TouchableOpacity
                onPress={() =>
                  this.setState({
                    userData: 1,
                    hobbies: this.state.hobbiesUserAldo,
                    books: this.state.booksAldo,
                  })
                }
                style={{
                  width: '20%',
                  borderWidth: 1,
                  borderRadius: 5,
                  alignContent: 'center',
                  alignItems: 'center',
                  backgroundColor: '#D21453',
                }}>
                <Text>Aldo</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() =>
                  this.setState({
                    userData: 2,
                    hobbies: this.state.hobbiesUserRei,
                    books: this.state.booksRei,
                  })
                }
                style={{
                  width: '20%',
                  borderWidth: 1,
                  borderRadius: 5,
                  alignContent: 'center',
                  alignItems: 'center',
                  backgroundColor: '#D21453',
                }}>
                <Text>Rei</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() =>
                  this.setState({
                    userData: 3,
                    hobbies: this.state.hobbiesUserFrancisco,
                    books: this.state.booksFrancisco,
                  })
                }
                style={{
                  width: '23%',
                  borderWidth: 1,
                  borderRadius: 5,
                  alignContent: 'center',
                  alignItems: 'center',
                  backgroundColor: '#D21453',
                }}>
                <Text>Francisco</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() =>
                  this.setState({
                    userData: 4,
                    hobbies: this.state.hobbiesUserAlice,
                    books: this.state.booksAlice,
                  })
                }
                style={{
                  width: '20%',
                  borderWidth: 1,
                  borderRadius: 5,
                  alignContent: 'center',
                  alignItems: 'center',
                  backgroundColor: '#D21453',
                }}>
                <Text>Alice</Text>
              </TouchableOpacity>
            </View>
          </View>
          <View>
            <Text style={{fontSize: 24, fontWeight: 'bold', color: '#333'}}>
              Informacion Basica:
            </Text>
            {this.userList()}
          </View>
          <View>
            <Text style={{fontSize: 24, fontWeight: 'bold', color: '#333'}}>
              Pasatiempos:
            </Text>
            {this.hobbiesList()}
          </View>
          <View>
            <Text style={{fontSize: 24, fontWeight: 'bold', color: '#333'}}>
              Libros Favoritos:
            </Text>
            {this.favoriteBooks()}
          </View>
        </ScrollView>
      </View>
    );
  }
}

export default perfilUser;
